import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface User {
  id: string;
  name: string;
  email?: string;
  profileImage?: string;
}

export interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  login: (provider?: 'google' | 'apple' | 'kakao') => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const login = async (provider?: 'google' | 'apple' | 'kakao') => {
    // 실제 구현에서는 기존 소셜 로그인 시스템 연동
    // 여기서는 데모용으로 즉시 로그인 처리
    setIsAuthenticated(true);
    setUser({
      id: 'user1',
      name: '김서예',
      email: 'user@example.com',
      profileImage: undefined
    });
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      user,
      login,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};