import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useAuth } from '../contexts/AuthContext';
import { PenTool, Sparkles, Users, Zap } from 'lucide-react';

export const Landing: React.FC = () => {
  const { login } = useAuth();

  const features = [
    {
      icon: <PenTool className="w-6 h-6" />,
      title: "AI 피드백",
      description: "실시간 평가와 맞춤 조언"
    },
    {
      icon: <Sparkles className="w-6 h-6" />,
      title: "체계적 학습",
      description: "기초부터 고급까지 단계별"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "모든 연령",
      description: "어린이부터 성인까지"
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "즉시 시작",
      description: "복잡한 설정 없이 바로"
    }
  ];

  const handleSocialLogin = (provider: 'google' | 'apple' | 'kakao') => {
    login(provider);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* 헤더 */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="flex items-center justify-center max-w-md mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <PenTool className="w-4 h-4 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-medium">서예 코치</h1>
          </div>
        </div>
      </header>

      {/* 메인 컨텐츠 */}
      <main className="max-w-md mx-auto px-6 py-12 space-y-12">
        
        {/* 히어로 섹션 */}
        <section className="text-center space-y-8">
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1753552502151-93914d36ecf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx6ZW4lMjBtZWRpdGF0aW9uJTIwd29ya3NwYWNlJTIwbWluaW1hbHxlbnwxfHx8fDE3NTg1NDMzNDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Zen Workspace"
              className="w-64 h-40 object-cover rounded-xl mx-auto shadow-sm"
            />
          </div>
          
          <div className="space-y-4">
            <h2 className="text-3xl font-medium leading-tight">
              AI와 함께 배우는<br />
              디지털 서예
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              언제 어디서나 쉽고 재미있게<br />
              전통 서예를 배워보세요
            </p>
          </div>
        </section>

        {/* 기능 소개 */}
        <section className="space-y-6">
          <h3 className="text-center font-medium">핵심 기능</h3>
          <div className="grid grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <Card key={index} className="p-4 text-center space-y-3">
                <div className="w-12 h-12 rounded-lg bg-muted mx-auto flex items-center justify-center">
                  {feature.icon}
                </div>
                <div className="space-y-1">
                  <h4 className="font-medium text-sm">{feature.title}</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* 로그인 영역 */}
        <section className="space-y-6">
          <div className="text-center space-y-2">
            <h3 className="font-medium">지금 시작하기</h3>
            <p className="text-sm text-muted-foreground">
              간편 로그인으로 바로 시작하세요
            </p>
          </div>
          
          <div className="space-y-3">
            <Button
              onClick={() => handleSocialLogin('google')}
              variant="outline"
              className="w-full h-12 justify-center gap-3"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Google로 시작하기
            </Button>
            
            <Button
              onClick={() => handleSocialLogin('kakao')}
              className="w-full h-12 justify-center gap-3 bg-yellow-400 hover:bg-yellow-500 text-yellow-900"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 3c5.799 0 10.5 3.664 10.5 8.185 0 4.52-4.701 8.184-10.5 8.184a13.5 13.5 0 01-1.727-.11L6.565 21l1.101-2.757C5.565 16.962 1.5 13.647 1.5 11.185 1.5 6.664 6.201 3 12 3z"/>
              </svg>
              카카오로 시작하기
            </Button>
            
            <Button
              onClick={() => handleSocialLogin('apple')}
              className="w-full h-12 justify-center gap-3"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
              </svg>
              Apple로 시작하기
            </Button>
          </div>
        </section>

        {/* 푸터 */}
        <footer className="text-center space-y-3 pt-8">
          <p className="text-xs text-muted-foreground">
            © 2024 서예 코치. 모든 권리 보유.
          </p>
          <div className="flex justify-center gap-4 text-xs">
            <button className="text-muted-foreground hover:text-foreground transition-colors">
              이용약관
            </button>
            <button className="text-muted-foreground hover:text-foreground transition-colors">
              개인정보처리방침
            </button>
          </div>
        </footer>
      </main>
    </div>
  );
};