import React, { useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  ArrowLeft, 
  RotateCcw, 
  Eraser, 
  Camera, 
  Pen, 
  Eye,
  Play,
  Square,
  Check
} from 'lucide-react';

export const PracticeScreen: React.FC = () => {
  const navigate = useNavigate();
  const { courseType, lessonId } = useParams<{ courseType: string; lessonId: string }>();
  
  // 한자능력시험 특별판인 경우 HanjaLearnScreen으로 리다이렉트
  React.useEffect(() => {
    if (courseType?.startsWith('test-hanja-')) {
      navigate(`/hanja/${courseType}-${lessonId}`, { replace: true });
      return;
    }
  }, [courseType, lessonId, navigate]);
  
  // 한자능력시험이면 빈 화면 반환 (리다이렉트 처리 중)
  if (courseType?.startsWith('test-hanja-')) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto animate-pulse">
            <div className="w-6 h-6 rounded-full bg-primary animate-spin"></div>
          </div>
          <p className="text-muted-foreground">학습 페이지로 이동 중...</p>
        </div>
      </div>
    );
  }
  
  const { sessionId } = useParams();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [currentCharacterIndex, setCurrentCharacterIndex] = useState(0);
  const [practiceMode, setPracticeMode] = useState<'digital' | 'photo'>('digital');
  const [isDrawing, setIsDrawing] = useState(false);
  const [showStrokeGuide, setShowStrokeGuide] = useState(true);
  const [isCapturing, setIsCapturing] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);

  // 한자/한글 모드 감지
  const isHanjaMode = sessionId?.startsWith('hanja_');
  
  // 임시 연습 데이터
  const practiceSession = isHanjaMode ? {
    id: sessionId,
    course: '기초 한자',
    characters: ['宇', '宙', '星', '月', '日'],
    currentCharacter: '宇',
    totalCharacters: 5,
    type: 'hanja' as const
  } : {
    id: sessionId,
    course: '판본체 기초',
    characters: ['가', '나', '다', '라', '마'],
    currentCharacter: '가',
    totalCharacters: 5,
    type: 'hangeul' as const
  };

  const currentCharacter = practiceSession.characters[currentCharacterIndex];
  const progress = ((currentCharacterIndex + 1) / practiceSession.totalCharacters) * 100;

  // Canvas 그리기 관련 함수들 (실제로는 기존 구현과 연동)
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (practiceMode !== 'digital') return;
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || practiceMode !== 'digital') return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.strokeStyle = '#2C3E50';
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      drawGrid();
    }
  };

  const drawGrid = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.strokeStyle = '#E5E7EB';
    ctx.lineWidth = 1;
    
    // 격자 그리기
    const gridSize = 20;
    for (let x = 0; x <= canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    
    for (let y = 0; y <= canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }
    
    // 중앙선
    ctx.strokeStyle = '#9CA3AF';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, 0);
    ctx.lineTo(canvas.width / 2, canvas.height);
    ctx.moveTo(0, canvas.height / 2);
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();
  };

  React.useEffect(() => {
    drawGrid();
  }, []);

  // 실물 모드로 전환시 카메라 초기화
  React.useEffect(() => {
    if (practiceMode === 'photo') {
      setCameraReady(false);
      // 카메라 접근 시도
      setTimeout(() => {
        setCameraReady(true);
      }, 1000);
    }
  }, [practiceMode]);

  const handlePhotoCapture = () => {
    setIsCapturing(true);
    // 실제로는 Camera API 호출
    setTimeout(() => {
      setIsCapturing(false);
      // 촬영 완��� 후 처리
    }, 2000);
  };

  const handleComplete = () => {
    // 평가 요청 후 결과 페이지로 이동
    navigate(`/result/attempt_${Date.now()}`);
  };

  const handleNext = () => {
    if (currentCharacterIndex < practiceSession.characters.length - 1) {
      setCurrentCharacterIndex(prev => prev + 1);
      clearCanvas();
    } else {
      // 세션 완료
      handleComplete();
    }
  };

  const handleExit = () => {
    if (window.confirm('연습을 종료하시겠습니까? 현재 진행 상황이 저장됩니다.')) {
      navigate('/home');
    }
  };

  return (
    <div className="min-h-screen calligraphy-bg flex flex-col">
      {/* 상단 바 */}
      <header className="px-6 py-4 organic-header">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate(`/learn/${courseType}/curriculum`)}
            className="text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <div className="flex-1 mx-4">
            <div className="text-center space-y-1">
              <p className="text-sm font-medium text-primary">
                {currentCharacterIndex + 1}/{practiceSession.totalCharacters}
              </p>
              <Progress value={progress} className="h-2" />
            </div>
          </div>
          
          <p className="text-sm text-muted-foreground">{practiceSession.course}</p>
        </div>
      </header>

      {/* 메인 컨텐츠 */}
      <main className="flex-1 px-6 py-6">
        <div className="max-w-md mx-auto space-y-6 h-full">
          {/* 현재 글자 표시 */}
          <div className="character-display p-8 text-center">
            <h2 className="text-sm text-muted-foreground mb-4">연습할 글자</h2>
            <div className="text-8xl font-medium text-primary mb-6 ink-splash relative">
              {currentCharacter}
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-16 h-1 bg-gradient-to-r from-transparent via-primary/30 to-transparent rounded-full"></div>
            </div>
            <div className="flex justify-center items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowStrokeGuide(!showStrokeGuide)}
                className="text-muted-foreground hover:text-primary"
              >
                <Eye className="w-4 h-4 mr-1" />
                {showStrokeGuide ? '가이드 숨기기' : '가이드 보기'}
              </Button>
            </div>
          </div>

          {/* 연습 모드 전환 */}
          <Tabs value={practiceMode} onValueChange={(value) => setPracticeMode(value as any)}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="digital" className="flex items-center gap-2">
                <Pen className="w-4 h-4" />
                디지털
              </TabsTrigger>
              <TabsTrigger value="photo" className="flex items-center gap-2">
                <Camera className="w-4 h-4" />
                실물
              </TabsTrigger>
            </TabsList>

            {/* 디지털 모드 */}
            <TabsContent value="digital" className="space-y-6">
              <div className="handmade-card p-6">
                <div className="space-y-6">
                  <div className="relative">
                    <canvas
                      ref={canvasRef}
                      width={1400}
                      height={1400}
                      className="w-full cursor-crosshair bg-white canvas-frame"
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                    />
                    
                    {showStrokeGuide && (
                      <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                        <div className="relative">
                          <span className="text-[16rem] text-primary/25 font-black leading-none">
                            {currentCharacter}
                          </span>
                          {/* 한글 획순 가이드 */}
                          {!isHanjaMode && (
                            <>
                              {/* 첫 번째 획 시작점 (ㄱ) */}
                              <div className="absolute top-[15%] left-[10%] w-4 h-4 bg-red-500 rounded-full shadow-lg animate-pulse border-2 border-white">
                                <div className="absolute inset-0 bg-red-400 rounded-full animate-ping"></div>
                              </div>
                              {/* 첫 번째 획 방향 화살표 */}
                              <div className="absolute top-[15%] left-[15%]">
                                <svg width="24" height="12" viewBox="0 0 24 12" className="text-red-500">
                                  <path d="M2 6 L18 6 M15 3 L18 6 L15 9" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                                </svg>
                              </div>
                              
                              {/* 두 번째 획 시작점 (ㅏ) */}
                              <div className="absolute top-[15%] right-[25%] w-3 h-3 bg-red-500 rounded-full shadow-lg animate-pulse border-2 border-white">
                                <div className="absolute inset-0 bg-red-400 rounded-full animate-ping"></div>
                              </div>
                            </>
                          )}
                          
                          {/* 한자 획순 가이드 - 宇 */}
                          {isHanjaMode && currentCharacter === '宇' && (
                            <>
                              {/* 첫 번째 획: 갓머리 가로획 */}
                              <div className="absolute top-[18%] left-[20%] w-4 h-4 bg-blue-500 rounded-full shadow-lg animate-pulse border-2 border-white">
                                <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping"></div>
                                <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-blue-600 font-bold">1</div>
                              </div>
                              
                              {/* 두 번째 획: 갓머리 세로+가로 */}
                              <div className="absolute top-[25%] left-[35%] w-3 h-3 bg-green-500 rounded-full shadow-lg animate-pulse border-2 border-white">
                                <div className="absolute inset-0 bg-green-400 rounded-full animate-ping"></div>
                                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 text-xs text-green-600 font-bold">2</div>
                              </div>
                              
                              {/* 세 번째 획: 가로획 */}
                              <div className="absolute top-[45%] left-[25%] w-3 h-3 bg-orange-500 rounded-full shadow-lg animate-pulse border-2 border-white">
                                <div className="absolute inset-0 bg-orange-400 rounded-full animate-ping"></div>
                                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 text-xs text-orange-600 font-bold">3</div>
                              </div>
                              
                              {/* 네 번째 획: 세로획 */}
                              <div className="absolute top-[55%] left-[50%] w-3 h-3 bg-purple-500 rounded-full shadow-lg animate-pulse border-2 border-white">
                                <div className="absolute inset-0 bg-purple-400 rounded-full animate-ping"></div>
                                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 text-xs text-purple-600 font-bold">4</div>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex justify-center gap-2">
                    <Button variant="outline" size="sm" onClick={clearCanvas}>
                      <Eraser className="w-4 h-4 mr-1" />
                      지우기
                    </Button>
                    <Button variant="outline" size="sm">
                      <RotateCcw className="w-4 h-4 mr-1" />
                      되돌리기
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* 실물 모드 */}
            <TabsContent value="photo" className="space-y-6">
              <div className="handmade-card p-6">
                <div className="space-y-4">
                  <div className="aspect-square bg-black rounded-lg relative overflow-hidden">
                    {/* 카메라 스트림 */}
                    <video 
                      ref={React.useRef<HTMLVideoElement>(null)}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                      onLoadedMetadata={(e) => {
                        // 카메라 스트림 시작
                        navigator.mediaDevices.getUserMedia({ 
                          video: { facingMode: 'environment' } 
                        }).then(stream => {
                          if (e.currentTarget) {
                            e.currentTarget.srcObject = stream;
                            setCameraReady(true);
                          }
                        }).catch(() => {
                          // 카메라 접근 실패시에도 UI는 표시
                          setCameraReady(true);
                        });
                      }}
                    />
                    
                    {/* 격자 오버레이 */}
                    <div className="absolute inset-0 pointer-events-none z-10">
                      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                        {/* 3x3 격자 */}
                        <defs>
                          <pattern id="camera-grid" width="33.33" height="33.33" patternUnits="userSpaceOnUse">
                            <path d="M 33.33 0 L 0 0 0 33.33" fill="none" stroke="rgba(255,255,255,0.6)" strokeWidth="0.8"/>
                          </pattern>
                        </defs>
                        <rect width="100" height="100" fill="url(#camera-grid)" />
                        
                        {/* 중앙선 강조 */}
                        <line x1="50" y1="0" x2="50" y2="100" stroke="rgba(255,255,255,0.8)" strokeWidth="1.5"/>
                        <line x1="0" y1="50" x2="100" y2="50" stroke="rgba(255,255,255,0.8)" strokeWidth="1.5"/>
                      </svg>
                    </div>
                    
                    {/* 가운데 표시점 */}
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
                      <div className="w-4 h-4 bg-white rounded-full shadow-lg border-2 border-black/30">
                        <div className="w-2 h-2 bg-black rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                      </div>
                      {/* 십자선 */}
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                        <div className="w-8 h-0.5 bg-white/80 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                        <div className="h-8 w-0.5 bg-white/80 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                      </div>
                    </div>
                    
                    {/* 가이드 글자 (반투명) */}
                    {showStrokeGuide && (
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-15">
                        <span className="text-[16rem] text-white/30 font-black leading-none">
                          {currentCharacter}
                        </span>
                      </div>
                    )}
                    
                    {/* 카메라 로딩 상태 */}
                    {!cameraReady && (
                      <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-30">
                        <div className="text-center space-y-4">
                          <Camera className="w-16 h-16 text-white/60 mx-auto" />
                          <p className="text-sm text-white/80">���메라를 준비하는 중...</p>
                        </div>
                      </div>
                    )}
                    
                    {/* 촬영 중 오버레이 */}
                    {isCapturing && (
                      <div className="absolute inset-0 bg-white/90 flex items-center justify-center z-40">
                        <div className="text-center space-y-4">
                          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
                          <p className="text-sm text-primary">촬영 중...</p>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      variant="outline"
                      onClick={() => setShowStrokeGuide(!showStrokeGuide)}
                      className="h-12"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      {showStrokeGuide ? '가이드 숨기기' : '가이드 보기'}
                    </Button>
                    <Button 
                      onClick={handlePhotoCapture}
                      disabled={isCapturing}
                      className="h-12"
                    >
                      <Camera className="w-5 h-5 mr-2" />
                      {isCapturing ? '촬영 중...' : '촬영하기'}
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* 완료 버튼 */}
          <Button 
            onClick={handleComplete}
            className="w-full h-12"
            size="lg"
          >
            <Check className="w-5 h-5 mr-2" />
            평가 받기
          </Button>
        </div>
      </main>
    </div>
  );
};