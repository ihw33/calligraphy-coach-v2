import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  ArrowLeft, 
  Star, 
  TrendingUp, 
  RotateCcw, 
  ArrowRight,
  Award,
  Target,
  Lightbulb
} from 'lucide-react';

export const ResultScreen: React.FC = () => {
  const navigate = useNavigate();
  const { attemptId } = useParams();

  // 임시 평가 결과 데이터 (실제로는 API에서 가져옴)
  const evaluationResult = {
    id: attemptId,
    character: '가',
    course: '판본체 기초',
    overallMessage: "훌륭해요! 기본 획의 균형이 잘 잡혀있습니다. 특히 가로획과 세로획의 비례가 아주 좋아요. 조금 더 연습하면 더욱 아름다운 글씨가 될 것 같습니다.",
    score: 85, // 내부 사용, 사용자에게는 숨김
    strengths: [
      "획의 굵기가 일정하고 안정적입니다",
      "글자의 중심이 잘 잡혀있어요",
      "전체적인 비례감이 우수합니다"
    ],
    improvements: [
      "첫 번째 가로획을 조금 더 길게 써보세요",
      "마지막 획의 끝부분을 더 깔끔하게 마무리해보세요"
    ],
    currentSession: {
      progress: 2,
      total: 5,
      nextCharacter: '나'
    }
  };

  const handleRetry = () => {
    navigate('/practice/session1'); // 현재 세션으로 다시 돌아가기
  };

  const handleNext = () => {
    if (evaluationResult.currentSession.progress < evaluationResult.currentSession.total) {
      navigate('/practice/session1'); // 다음 글자로 진행
    } else {
      navigate('/home'); // 세션 완료
    }
  };

  const handleHome = () => {
    navigate('/home');
  };

  const sessionProgress = (evaluationResult.currentSession.progress / evaluationResult.currentSession.total) * 100;

  return (
    <div className="min-h-screen bg-background">
      {/* 헤더 */}
      <header className="px-6 py-4 border-b bg-card/50">
        <div className="flex items-center gap-3 max-w-md mx-auto">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={handleHome}
            className="text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-medium text-primary">평가 결과</h1>
            <p className="text-sm text-muted-foreground">{evaluationResult.course}</p>
          </div>
        </div>
      </header>

      {/* 메인 컨텐츠 */}
      <main className="px-6 py-6 pb-32">
        <div className="max-w-md mx-auto space-y-6">
          {/* 현재 세션 진행률 */}
          <Card className="p-4 bg-primary/5 border-primary/20">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">세션 진행률</span>
                <span className="text-sm font-medium text-primary">
                  {evaluationResult.currentSession.progress}/{evaluationResult.currentSession.total}
                </span>
              </div>
              <Progress value={sessionProgress} className="h-2" />
            </div>
          </Card>

          {/* 작성한 글자 */}
          <Card className="p-6 text-center">
            <h2 className="text-sm text-muted-foreground mb-4">연습한 글자</h2>
            <div className="text-6xl font-medium text-primary mb-4">
              {evaluationResult.character}
            </div>
            <Badge className="bg-primary/10 text-primary border-primary/20">
              {evaluationResult.course}
            </Badge>
          </Card>

          {/* 전체 평가 메시지 */}
          <Card className="p-6 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center">
                <Star className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-medium text-primary">AI 서예 코치의 평가</h3>
            </div>
            
            <p className="text-muted-foreground leading-relaxed">
              {evaluationResult.overallMessage}
            </p>
          </Card>

          {/* 잘한 점 */}
          <Card className="p-6 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <Award className="w-4 h-4 text-green-600" />
              </div>
              <h3 className="font-medium text-primary">잘한 점</h3>
            </div>
            
            <div className="space-y-2">
              {evaluationResult.strengths.map((strength, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-green-500 mt-2 flex-shrink-0" />
                  <p className="text-sm text-green-800">{strength}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* 개선할 점 */}
          <Card className="p-6 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                <Lightbulb className="w-4 h-4 text-blue-600" />
              </div>
              <h3 className="font-medium text-primary">개선할 점</h3>
            </div>
            
            <div className="space-y-2">
              {evaluationResult.improvements.map((improvement, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0" />
                  <p className="text-sm text-blue-800">{improvement}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* 학습 팁 */}
          <Card className="p-6 space-y-4 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-600" />
              <h3 className="font-medium text-purple-800">학습 팁</h3>
            </div>
            
            <div className="space-y-2">
              <p className="text-sm text-purple-700">
                • 붓의 각도를 일정하게 유지하며 연습해보세요
              </p>
              <p className="text-sm text-purple-700">
                • 천천히 써서 각 획의 시작과 끝을 의식해보세요
              </p>
              <p className="text-sm text-purple-700">
                • 표준 글자를 자주 보며 형태를 기억해보세요
              </p>
            </div>
          </Card>
        </div>
      </main>

      {/* 하단 액션 버튼 */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-background border-t">
        <div className="max-w-md mx-auto space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="outline"
              onClick={handleRetry}
              className="h-12 bg-white/80 border-2 border-border hover:bg-white/90 backdrop-blur-sm"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              다시 쓰기
            </Button>
            
            <Button 
              onClick={handleNext}
              className="h-12 bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {evaluationResult.currentSession.progress < evaluationResult.currentSession.total ? (
                <>
                  <ArrowRight className="w-4 h-4 mr-2" />
                  다음 글자 ({evaluationResult.currentSession.nextCharacter})
                </>
              ) : (
                <>
                  <Award className="w-4 h-4 mr-2" />
                  완료
                </>
              )}
            </Button>
          </div>
          
          <Button 
            variant="ghost" 
            onClick={handleHome}
            className="w-full text-muted-foreground hover:text-primary"
          >
            홈으로 돌아가기
          </Button>
        </div>
      </div>
    </div>
  );
};