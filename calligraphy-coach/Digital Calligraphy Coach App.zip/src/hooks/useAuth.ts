import { useState } from 'react';

export interface User {
  id: string;
  name: string;
  email?: string;
  profileImage?: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  login: (provider?: 'google' | 'apple' | 'kakao') => Promise<void>;
  logout: () => void;
}

// 임시 모킹된 인증 훅 (실제 구현과 연동시 교체)
export const useAuth = (): AuthState => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const login = async (provider?: 'google' | 'apple' | 'kakao') => {
    // 실제 구현에서는 기존 소셜 로그인 시스템 연동
    setIsAuthenticated(true);
    setUser({
      id: 'user1',
      name: '김서예',
      email: 'user@example.com'
    });
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
  };

  return {
    isAuthenticated,
    user,
    login,
    logout
  };
};